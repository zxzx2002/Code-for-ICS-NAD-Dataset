class FlowGeneratorActions:
    SNIFF = "sniff"
    CONVERT = "convert"

